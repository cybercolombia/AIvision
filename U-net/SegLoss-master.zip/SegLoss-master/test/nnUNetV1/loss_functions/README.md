PyTorch Implementation of Commonly used loss functions in medical image segmentation tasks.

Borrow some code from
- [nnUNet](https://github.com/MIC-DKFZ/nnUNet)
- [Loss_ToolBox-PyTorch](https://github.com/Hsuxu/Loss_ToolBox-PyTorch)
- [3D U-Net](https://github.com/wolny/pytorch-3dunet/blob/master/unet3d/losses.py)
